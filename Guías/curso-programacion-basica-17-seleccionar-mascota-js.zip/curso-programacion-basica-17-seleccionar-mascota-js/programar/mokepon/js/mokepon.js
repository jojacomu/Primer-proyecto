function seleccionarMascotaJugador() {
    alert('SELECCIONASTE TU MASCOTA')
}

let botonMascotaJugador = document.getElementById('boton-mascota')
botonMascotaJugador.addEventListener('click', seleccionarMascotaJugador)
